This is the v41 firmware upgrade file for the V2 version of the Monoprice Select Mini 3D Printer. The v40 firmware upgrade must be installed before installing the v41 upgrade.

Refer to the following link for detailed firmware update instructions: https://mpselectmini.com/firmware/motion_controller